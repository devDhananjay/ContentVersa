(function(){function e(){let e=new URLSearchParams(location.search).get(`token`);e&&chrome.runtime.sendMessage({type:`JOBPILOT_SET_TOKEN`,token:e},()=>{})}e(),new MutationObserver(()=>e()).observe(document.documentElement,{childList:!0,subtree:!0});
//# sourceMappingURL=login-bridge.ts-BhS_SHTt.js.map})()
